# 滚动测试版源码

本包包含未正式发布的可靠性及模型接入窗口更新，请先阅读 docs/reliability-update.md 和 docs/model-settings-update.md。来源为 manifest 中基线提交加当前工作区修改。

使用 Python 3.11+：`python -m pip install -e ".[desktop,dev]"`，然后 `python desktop_entry.py --data-dir outputs/test-data`。
不包含用户数据、密钥、运行环境或 EXE。SOURCE_MANIFEST.json 可逐文件校验。
