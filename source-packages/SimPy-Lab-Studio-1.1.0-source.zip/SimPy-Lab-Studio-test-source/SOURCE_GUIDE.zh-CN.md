# SimPy Lab Studio — 测试版源码说明

本包为可独立解压使用的完整源码快照，不是软件安装程序。

- 对应分支：`frontend/simulation-workspace`
- 来源提交：`8f0da32e78a5534a92b91bc5463e0f95b9114b32`
- 仓库：https://github.com/Sylphiette666/SimPy-Lab-Studio
- 快照包括 102 个源码及文档文件，保留原路径与文件内容；排除 source-packages 中的历史打包文件以免递归打包。
- 未包含个人实验数据、真实 API 密钥、虚拟环境、运行库、构建缓存、成品 EXE 或其他源码包。
- 此说明和 `SOURCE_MANIFEST.json` 是整理时补充的文件，原程序源码未改写。

## 目录导航

| 路径 | 用途 |
| --- | --- |
| `desktop_entry.py`、`desktop.spec` | 桌面启动入口、EXE 打包配置 |
| `src/simlab/static/studio/` | HTML、CSS、JavaScript、图标等界面资源 |
| `src/simlab/manufacturing.py`、`live_manufacturing.py` | 制造模型和可视化采样逻辑 |
| `src/simlab/studio.py`、`studio_ai.py`、`studio_profiles.py` | 应用服务、AI 修改、模型接入配置 |
| `src/simlab/` 的其他模块 | 仿真、指标、实验、CLI 等功能 |
| `tests/` | 单元与集成测试、注入 AI 的浏览器测试服务 |
| `tools/` | 桌面/安装程序构建工具、浏览器验证脚本 |
| `installer/` | 安装向导脚本与组件许可 |
| `docs/`、`examples/` | 使用说明、案例说明、界面截图、示例模型 |
| `pyproject.toml`、`LICENSE` | 依赖和项目配置、MIT 许可证 |

## 解压后运行

在 Windows 的 PowerShell 中进入解压后的根目录，准备 Python 3.11+：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -e ".[desktop,desktop-build,dev]"
.venv\Scripts\python.exe desktop_entry.py --data-dir outputs/source-trial
```

原生窗口需要 Microsoft Edge WebView2 Runtime；安装依赖需要联网。软件自动启动后台服务。
两个版本沿用同一单实例机制，切换版本前先关闭正在运行的版本。
以上命令把体验数据放在当前源码目录的 `outputs/source-trial`，不使用正常安装版的数据目录。
API 密钥由使用者自行配置；仅保存配置并不代表已验证服务连接。

## 构建与验证

```powershell
# 构建带图标的独立 EXE：dist/SimPy Lab Studio.exe
.venv\Scripts\python.exe tools/build_desktop.py

# 安装 Inno Setup 6.7+ 后，可另行构建安装程序
.\tools\build_installer.ps1 -Python .venv\Scripts\python.exe

# 单元与集成测试
.venv\Scripts\python.exe -m pytest
```

依赖版本范围由 `pyproject.toml` 指定，本包未附离线依赖或锁定的完整构建环境。
许可证页面和安装向导图片等生成文件由构建脚本生成，不属于缺失源码。
请把构建产物保存在各自解压目录中，避免覆盖已经保留的成品软件。

测试版包含 `workspace.css`、`workspace.js`，SimPy 引擎和指标计算与第一版一致，AI 接入适配已包含响应完整性修复；详见 `docs/ai-response-fix.md`。流程和浏览器测试步骤见 `docs/workspace-redesign.md`；该版本的原生宿主仍沿用 1.0.0 版本号，界面显示“测试版”。

## 校验

外部 `.zip.sha256` 文件校验整个 ZIP；包内 `SOURCE_MANIFEST.json` 列出原始文件的路径、字节数、SHA-256 与 Git blob ID，可确认来源。源码快照对应上列提交，不包含上传源码包后新增的打包说明提交。
