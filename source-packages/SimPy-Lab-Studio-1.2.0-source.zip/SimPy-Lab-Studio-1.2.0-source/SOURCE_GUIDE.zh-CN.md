# SimPy Lab Studio 正式版 v1.2.0 — 源码说明

完整源码快照，对应 v1.2.0；不是安装程序。

- 仓库：https://github.com/Sylphiette666/SimPy-Lab-Studio
- 对应分支：`main`
- 来源提交：`5502cc477ea05e443d3c675cb906fdfdb94a7069`
- 包含 190 个 Git 原始文件，保留文件内容和目录结构。
- 为避免递归打包，排除 `source-packages/` 中的发行归档。
- 不含用户实验、真实 API 密钥或密文、虚拟环境、构建缓存、成品 EXE。
- 包内 `SOURCE_MANIFEST.json` 列出每个文件的大小、SHA-256 与 Git blob ID。

## 运行和构建

先阅读 `README.md`。Windows 上准备 Python 3.11+，在解压后的源码根目录运行：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -e ".[desktop,desktop-build,dev]"
.venv\Scripts\python.exe desktop_entry.py --data-dir outputs/source-trial
```

需要 Microsoft WebView2 Runtime。命令使用独立试用数据目录，不修改正常安装版的数据。切换版本前先关闭已有软件；API 服务由用户自行配置。

```powershell
.venv\Scripts\python.exe tools/build_desktop.py
.\tools\build_installer.ps1 -Python .venv\Scripts\python.exe
.venv\Scripts\python.exe -m pytest
```

安装包构建需要 Inno Setup 6.7+。依赖范围由 `pyproject.toml` 指定，未附完整离线运行库或环境锁文件；许可证页面、安装向导图片等由构建脚本生成。

## 目录导航

- `desktop_entry.py`、`desktop.spec`：桌面入口与 EXE 构建。
- `src/simlab/static/studio/`：界面代码、图标、离线对话组件和许可。
- `src/simlab/`：仿真、统计、服务、AI 接入及 Windows 加密保存。
- `tests/`、`tools/`：程序测试、交互验证和构建工具。
- `installer/`：安装向导脚本、语言与许可。
- `docs/`、`examples/`：使用文档、案例和示例模型。

v1.2.0 包含图形建模、对话工具、可选加密密钥保存和历史方案完整评估，保留串联仿真与统计计算。详情见 `docs/releases/v1.2.0.md`。测试分支在本次发布时同步到正式版，后续迭代继续覆盖同一测试包。

源码快照固定于上列提交；发布时新增的归档文件提交不包含在自身 ZIP 内。外部 `.zip.sha256` 校验整个压缩包，清单不对自身作循环校验。
